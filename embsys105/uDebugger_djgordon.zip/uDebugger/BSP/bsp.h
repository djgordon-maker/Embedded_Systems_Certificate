#ifndef __BSP_H
#define __BSP_H

// Add interfaces to the specific hardware for use by application code
#include "hw_init.h"
#include "uart.h"

#endif /* __BSP_H */